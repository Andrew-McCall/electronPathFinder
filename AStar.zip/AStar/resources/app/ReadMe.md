# Electron Path Finder

Example Of Editor and Animation
![Gif Of using the app](https://i.imgur.com/jZKwisf.gif)

Example Of Full Desktop App Complete
![Icon](https://i.imgur.com/9gh3OVd.png)


## Download Package


Don't trust random .exe from the web

## Future Improvements
- Save Drawing
- Default Drawing
- Recursive Path Backtrack
- Variable Animation Speed

## Licence
MIT License

Copyright (c) 2022 Andrew McCall